package com.example.newauth.utils;

public class Region {

}
