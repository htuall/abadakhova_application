package com.example.newauth;

public interface OnWordListener {
    void onWord(String word, String translation);
}
