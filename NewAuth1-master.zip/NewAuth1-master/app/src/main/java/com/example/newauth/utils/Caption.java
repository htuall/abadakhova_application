package com.example.newauth.utils;

public class Caption {
	
	public Style style;
	public Region region;
	
	public Time start;
	public Time end;
	
	public String content="";

}
